import { Memory } from "../../bot";

export interface WeatherMemory extends Memory {
    data: string[]
}