import { Memory } from "../../bot";

export interface RoomCleaningMemory extends Memory {
    data: Date | null
}