export enum Config {
    CLEANING_DELAY= 600000 // 10 minutes
    
}