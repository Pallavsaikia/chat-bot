import { Memory } from "..";

export interface DefaultMemory extends Memory {
    data: string[]
}