export interface Memory {
    data: any
}